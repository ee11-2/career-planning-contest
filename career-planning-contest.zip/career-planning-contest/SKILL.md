---
name: career-planning-contest
description: 全国大学生职业规划大赛（zgs.chsi.com.cn）报名全流程助手。当用户需要报名参赛、生成生涯发展报告 PDF 与生涯发展展示 PPT、在平台填表上传、完成生涯闯关、或批量帮同学代做并交付截图压缩包时使用。也适用于任何需要在类 Ant Design 的 React 站点上做持久化浏览器自动化（登录态易失、图形化卡片点击、受控组件赋值）的场景。
agent_created: true
---

# 职业规划大赛报名助手

把「读通知 → 判定赛道组别 → 生成两份材料 → 平台填表 → 打闯关 → 出交差截图」这条链固化下来。
核心价值不在写文案，而在**知道哪一步会卡、卡了怎么办**。

## 何时使用

- 用户发来大赛通知／操作手册／班级群截图，说"帮我报名""帮我搞了"
- 需要产出《生涯发展报告》PDF + 《生涯发展展示》PPT
- 需要在 zgs.chsi.com.cn 上填表、上传、打关、截图打包
- 已有账号登录态，需要在网页上做多次点击的持久化自动化

## 红线：先判断，再动手

动手前必须确认三件事，缺一件就问，不要替用户猜：

1. **年级 → 赛道**：一、二年级 = 成长赛道；三年级 = 就业赛道
2. **学历 → 组别**：专科/高职/职教本科 = **职教组**；普通本科 = 高教组。
   **选错组别是最常见的返工原因**，专科生误选高教组等于白填
3. **目标职业**：这是全文主轴，必须用户点头。动手前读
   `references/content-templates.md` 的选职业三原则，给出 2~3 个候选 + 权衡，让用户选

## 阶段一：读通知，定位硬约束

读三份文件：学校通知（赛程、名额、联系人）、省赛通知（材料规格）、学生操作手册（平台操作）。
只提取这几项，其余略过：

- 报名截止（学校往往早于省里的"1 月 20 日"，按学校的算）
- 材料规格：成长赛道 = 生涯发展报告（PDF ≤10MB，正文 ≤2000 字，图表 ≤5）+ 生涯发展展示（PPT ≤50MB）
- 提交形态：谁能改、什么时候锁死

## 阶段二：出两份材料

```bash
cp assets/body-template.html ./body.html      # 按模板替换方括号内容
python3 scripts/build_report.py --body body.html --check   # 先卡字数，汉字 ≤2000
python3 scripts/build_report.py --body body.html --out 生涯发展报告_姓名.pdf \
    --bar "三甲医院:79,二级医院:41,基层机构:12" \
    --radar "影像解剖|与检查技术:85:55,临床沟通|与培训:80:75,DICOM/PACS|与网络:90:15"
```

报告的写作要点全在 `references/content-templates.md`：三段式对应 25/50/25 的评分，
开头要反差数据，中间必须有能力雷达 + 三年时间轴，结尾必须有两次修正和 B 计划。

做 PPT：

```bash
# 12 页，先写 slides.html（每页一个 <section class="slide">），再一条龙转 PPTX
python3 scripts/build_deck.py --slides slides.html --out 生涯发展展示_姓名.pptx \
    --notes notes.json --scale 1.5
```

`assets/deck.css` 提供深色封面 + 浅色内容页的主题；`notes.json` 是字符串数组，
一条一页的逐字稿（7 分钟约 1100 字口语）。产物是图片版 PPTX——排版零跑版，
代价是文字不可编辑，比赛上传与放映完全够用。

## 阶段三：平台填表（浏览器驱动）

登录态是会话级 cookie，关掉浏览器就掉，所以要用**常驻进程**，不要一次一开。

```bash
# 1) 起驱动（会弹出一个持久化 profile 的窗口），放后台
python3 scripts/driver.py &

# 2) 让它停在登录页，请用户自己登录（微信扫码最省事）
python3 scripts/send.py '{"action":"goto","url":"https://zgs.chsi.com.cn/login"}'

# 3) 确认已登录：页面出现「你好，XXX」即成功
python3 scripts/send.py '{"action":"js","code":"document.body.innerText.slice(0,200)"}'
```

登录后按 `references/platform-map.md` 的字段表操作。要点：

- 组别单选：`input[type=radio]` 第 4 个（index 3）= 职教组
- 目标职业走「医疗类 → 其他」再自填，**≤10 字**
- 目标行业是 ant-select，输入「医」后点选 `医药卫生行业`
- 材料：`input[type=file]` 第 1 个塞 PDF，第 2 个塞 PPTX
- 指导教师弹窗：姓名 + 手机号 + 院校，**三项必填**，院校要先输入关键词再点下拉项
- 提交后会弹二次确认，需要再点一次「确定」

高层封装在 `scripts/ops.py`，直接用即可：

```python
import ops
ops.goto("https://zgs.chsi.com.cn/center/signup")
ops.click_text("编辑")                     # 真实鼠标点击，按文字定位
ops.fill_by_placeholder({"请输入姓名": "张三"})
ops.fill([None, None, "医学影像AI工程师"])  # 按顺序赋值，None 跳过
print(ops.errors())                        # 抓红字校验提示
ops.upload("input[type=file]", ["报告.pdf"])
```

## 阶段四：闯关与交差

闯关结构、每关要填什么、哪几关打不开，见 `references/platform-map.md` 第三节。
每关固定三步：新知（读）→ 笃行（填表）→ 领悟（写感想），**顺序不能反**。

交差物是两张截图 + 一个压缩包：

```python
ops.goto("https://zgs.chsi.com.cn/center/signup/view")
ops.shot("01_报名信息.png", full=True)     # 详情页信息最全
ops.goto("https://zgs.chsi.com.cn/mine/info")
ops.shot("02_生涯闯关.png", full=True)     # 徽章地图
```

```bash
python3 scripts/pack_shots.py --name "26影像1班-张三" --out 张三-职规赛截图.zip \
    "01_报名信息.png" "02_生涯闯关.png"
```

## 排查顺序（卡住就按这个查，别乱试）

1. 有没有红字校验 → `ops.errors()`；平台常常只提示"请输入"不提示哪一项
2. 输入框是不是空的 → `ops.fill()` 的返回值里出现 0 说明 React 没接住
3. 按钮点了没反应 → 换成 `ops.click_text()` 的真实鼠标；再不行抓 DOM 看是不是被浮层挡了
4. 页面空白 → 数一下控件：`document.querySelectorAll('input,textarea,button').length`
   为 0 且没有 iframe，就是平台侧没内容，**停手，让用户反馈**，不要反复重试
5. 掉登录 → 重新让用户扫码，别试图脚本化密码

## 给同学代做 / 收费服务的边界

这一条不可妥协：**事实必须由本人提供，AI 只做组织和排版。**

- 可以代做：结构、措辞、排版、数据检索、平台操作、截图打包
- 不可以代做：编造获奖、虚构访谈对象、杜撰实习单位、假造阅读经历
- 素材清单要发给对方确认，原话写明："以下内容需你本人确认属实"

原因很现实：大赛明确要求材料真实，涉假会取消参赛资格并追责。
代做赚的是"省时间"的钱，不是"造材料"的钱；把这条写进交付说明，反而是最省事的免责。

报价参考维度（不报具体数字，按当地行情）：材料份数 × 是否需要代跑平台 × 是否需要答辩辅导。
**平台登录必须由参赛者本人完成**（学信网账号等同身份，代登录有风险），
所以可行的分工是"你登录，我操作"，而不是"我全程代办"。

## 文件清单

| 文件 | 用途 |
|---|---|
| `scripts/driver.py` | 常驻浏览器驱动，文件队列收发命令 |
| `scripts/send.py` | 发命令 / 当库调用 `send.run({...})` |
| `scripts/ops.py` | 高层封装：click_text / fill / fill_by_placeholder / wait_url / errors |
| `scripts/build_report.py` | HTML 正文 → A4 PDF，顺带卡字数 |
| `scripts/build_deck.py` | slides.html → 逐页 PNG → 16:9 PPTX（可带备注） |
| `scripts/figures.py` | 柱状图 / 能力雷达 / 时间轴的 SVG 生成器 |
| `scripts/pack_shots.py` | 截图打成班委要的压缩包 |
| `assets/report.css` | A4 报告样式（**页边距写在这里**，API margin 无效） |
| `assets/deck.css` | 16:9 演示样式 |
| `assets/body-template.html` | 报告正文骨架，含图表占位符 |
| `references/platform-map.md` | 平台 URL、字段、闯关结构、已知缺陷 |
| `references/pitfalls.md` | 18 条踩坑记录 |
| `references/content-templates.md` | 选职业原则、报告三段式、闯关问答模板、PPT 大纲 |

## 环境要求

Python 3.10+；`playwright`（需 `playwright install chromium`）、`pypdf`、`python-pptx`、`pillow`。
导出 PDF 走 Chromium，本机不需要 Chrome 或 LibreOffice。
