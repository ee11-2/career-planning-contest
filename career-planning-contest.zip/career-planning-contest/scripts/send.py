#!/usr/bin/env python3
"""给 driver.py 发一条命令并等结果。

    python3 send.py '{"action":"js","code":"document.title"}'
    python3 send.py '{"action":"mouse","x":400,"y":300}'

也可当库用：
    import send
    send.run({"action": "goto", "url": "https://..."})
"""
import json
import os
import sys
import time

RUNDIR = os.environ.get("ZGS_RUN", "/tmp/zgs-helper")
CMD = os.path.join(RUNDIR, "cmd.json")
RES = os.path.join(RUNDIR, "res.json")


def run(obj, timeout=120):
    os.makedirs(RUNDIR, exist_ok=True)
    if os.path.exists(RES):
        os.remove(RES)
    tmp = CMD + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, CMD)
    t0 = time.time()
    while time.time() - t0 < timeout:
        if os.path.exists(RES):
            time.sleep(0.15)
            try:
                with open(RES, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        time.sleep(0.3)
    return {"ok": False, "err": "timeout: 驱动没响应，driver.py 起了吗？"}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    out = run(json.loads(sys.argv[1]))
    print(json.dumps(out, ensure_ascii=False, indent=1)[:4000])
