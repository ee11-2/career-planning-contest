#!/usr/bin/env python3
"""高层操作封装：把今天踩过的坑都固化进函数签名。

核心两条经验：
1) React 受控组件必须用「原生 setter + input 事件」赋值，直接改 .value 不生效。
2) 点击必须用真实鼠标（page.mouse.click）并先 scrollIntoView，
   对 SVG / 图形化卡片，合成事件常常不触发。
"""
import json
import time

import send as _send

JS_INPUTS = """(()=>[...document.querySelectorAll('input,textarea')].map((x,i)=>
  i+'|'+x.tagName+'|'+x.type+'|'+(x.placeholder||'')))()"""


def goto(url, wait=1.5, timeout=120):
    r = _send.run({"action": "goto", "url": url}, timeout=timeout)
    time.sleep(wait)
    return r


def js(code, timeout=120):
    r = _send.run({"action": "js", "code": code}, timeout=timeout)
    return r.get("value", r)


def url():
    return js("(()=>({u:location.href}))()").get("u")


def shot(path, full=False):
    return _send.run({"action": "shot", "path": path, "full": full})


def text(n=2000):
    r = _send.run({"action": "dump", "n": n})
    return r.get("text", "")


def inputs():
    """列出当前页所有输入框：[{i, tag, type, placeholder}]"""
    raw = js(JS_INPUTS) or []
    out = []
    for row in raw:
        i, tag, typ, ph = (row.split("|", 3) + ["", "", "", ""])[:4]
        out.append({"i": int(i), "tag": tag, "type": typ, "placeholder": ph})
    return out


def click_text(label, index=0, timeout=60):
    """按可见文字点击（真实鼠标）。index=0 取第一个，-1 取最后一个。"""
    code = (
        "(()=>{const L=" + json.dumps(label) + ";"
        "const all=[...document.querySelectorAll('*')].filter(e=>"
        "e.children.length===0 && (e.textContent||'').trim()===L);"
        "if(!all.length) return null;"
        "const e=all[(" + str(index) + " + all.length) % all.length];"
        "e.scrollIntoView({block:'center'});"
        "const r=e.getBoundingClientRect();"
        "return {x:Math.round(r.x+r.width/2), y:Math.round(r.y+r.height/2)};})()"
    )
    pos = js(code)
    if not pos:
        return {"ok": False, "err": "没找到文字：" + label}
    time.sleep(0.25)
    _send.run({"action": "mouse", "x": pos["x"], "y": pos["y"]}, timeout=timeout)
    time.sleep(2.5)
    return {"ok": True, "at": pos}


def click_xy(x, y, wait=2.5):
    _send.run({"action": "mouse", "x": int(x), "y": int(y)})
    time.sleep(wait)
    return {"ok": True}


def fill(values):
    """按文档顺序给 input/textarea 赋值。values 里 None 表示跳过该位置。

    返回每个框的实际长度，便于校验（0 通常意味着 React 没接住）。
    """
    code = (
        "(()=>{const ins=[...document.querySelectorAll('input,textarea')];"
        "const si=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;"
        "const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;"
        "const data=" + json.dumps(values, ensure_ascii=False) + ";"
        "ins.forEach((e,i)=>{const v=data[i]; if(v===undefined||v===null) return;"
        "  if(e.tagName==='INPUT') si.call(e,v); else st.call(e,v);"
        "  e.dispatchEvent(new Event('input',{bubbles:true}));"
        "  e.dispatchEvent(new Event('change',{bubbles:true}));});"
        "return ins.map(x=>x.value.length);})()"
    )
    return js(code)


def fill_by_placeholder(mapping):
    """{'请输入姓名': '张三', ...} 按 placeholder 精确赋值，比按序号稳。"""
    code = (
        "(()=>{const m=" + json.dumps(mapping, ensure_ascii=False) + ";"
        "const si=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;"
        "const st=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;"
        "const done={};"
        "document.querySelectorAll('input,textarea').forEach(e=>{"
        "  const ph=e.placeholder; if(!(ph in m)) return;"
        "  if(e.tagName==='INPUT') si.call(e,m[ph]); else st.call(e,m[ph]);"
        "  e.dispatchEvent(new Event('input',{bubbles:true}));"
        "  e.dispatchEvent(new Event('change',{bubbles:true}));"
        "  done[ph]=e.value.length;});"
        "return done;})()"
    )
    return js(code)


def upload(selector, files):
    return _send.run({"action": "upload", "sel": selector, "files": files})


def wait_text(needle, timeout=60, interval=2):
    """等到页面出现某段文字，返回 True/False。"""
    t0 = time.time()
    while time.time() - t0 < timeout:
        if needle in text(6000):
            return True
        time.sleep(interval)
    return False


def wait_url(part, timeout=60, interval=1.5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if part in (url() or ""):
            return True
        time.sleep(interval)
    return False


def errors():
    """抓表单红字校验提示。"""
    return js(
        "(()=>[...document.querySelectorAll('[class*=explain],[class*=error]')]"
        ".map(e=>(e.innerText||'').trim()).filter(Boolean).slice(0,8))()"
    )
