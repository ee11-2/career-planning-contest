#!/usr/bin/env python3
"""把数据画成内联 SVG（不依赖 matplotlib，中文字体不会掉）。

两个图形足够覆盖成长赛道报告：
  bar_svg([("三甲医院",79), ...])                   → 竖柱状图
  radar_svg([("影像解剖",85,55), ...])              → 五维能力雷达（需求 vs 现状）
"""
import math

NAVY = "#173B54"
TEAL = "#2E8B9E"
GOLD = "#C08A2E"


def bar_svg(items, width=300, height=200, base=158, maxh=112):
    inner = ""
    n = len(items)
    step = (width - 40) / max(n, 1)
    for i, (label, value) in enumerate(items):
        x = 24 + i * step + (step - 46) / 2
        h = maxh * value / 100.0
        label_v = int(value) if float(value).is_integer() else value
        color = TEAL if i < n - 1 else "#B9C6CE"
        inner += f'<rect x="{x:.1f}" y="{base - h:.1f}" width="46" height="{h:.1f}" rx="3" fill="{color}"/>'
        inner += (
            f'<text x="{x + 23:.1f}" y="{base - h - 8:.1f}" text-anchor="middle" '
            f'font-size="14" font-weight="700" fill="{NAVY}">{label_v}%</text>'
        )
        inner += (
            f'<text x="{x + 23:.1f}" y="{base + 17:.1f}" text-anchor="middle" '
            f'font-size="10" fill="#55666f">{label}</text>'
        )
    axis = f'<line x1="18" y1="{base}" x2="{width - 14}" y2="{base}" stroke="#c9d4da" stroke-width="1"/>'
    return f'<svg viewBox="0 0 {width} {height}" width="100%">{inner}{axis}</svg>'


def radar_svg(items, cx=170, cy=138, r=88, box=(340, 268)):
    """items: [(轴名, 需求值0-100, 现状值0-100), ...]"""
    n = len(items)
    if n < 3:
        return ""

    def poly(idx):
        pts = []
        for i, it in enumerate(items):
            a = -math.pi / 2 + 2 * math.pi * i / n
            v = it[idx] / 100.0
            pts.append(f"{cx + r * v * math.cos(a):.1f},{cy + r * v * math.sin(a):.1f}")
        return " ".join(pts)

    grid = ""
    for k in (25, 50, 75, 100):
        pts = []
        for i in range(n):
            a = -math.pi / 2 + 2 * math.pi * i / n
            rr = r * k / 100.0
            pts.append(f"{cx + rr * math.cos(a):.1f},{cy + rr * math.sin(a):.1f}")
        grid += f'<polygon points="{" ".join(pts)}" fill="none" stroke="#d3dde3" stroke-width="1"/>'

    spokes = ""
    for i in range(n):
        a = -math.pi / 2 + 2 * math.pi * i / n
        spokes += (
            f'<line x1="{cx}" y1="{cy}" x2="{cx + r * math.cos(a):.1f}" '
            f'y2="{cy + r * math.sin(a):.1f}" stroke="#d3dde3" stroke-width="1"/>'
        )

    labels = ""
    for i, it in enumerate(items):
        a = -math.pi / 2 + 2 * math.pi * i / n
        lx = cx + (r + 22) * math.cos(a)
        ly = cy + (r + 22) * math.sin(a)
        anchor = "middle"
        if math.cos(a) > 0.3:
            anchor = "start"
        elif math.cos(a) < -0.3:
            anchor = "end"
        dy = -8 if math.sin(a) < -0.5 else (12 if math.sin(a) > 0.5 else 0)
        parts = str(it[0]).split("|")  # 轴名里用 | 表示换行
        tspans = "".join(
            f'<tspan x="{lx:.1f}" dy="{0 if j == 0 else 11}">{s}</tspan>' for j, s in enumerate(parts)
        )
        labels += (
            f'<text x="{lx:.1f}" y="{ly + dy:.1f}" text-anchor="{anchor}" '
            f'font-size="9" fill="#4a5b66">{tspans}</text>'
        )

    return (
        f'<svg viewBox="0 0 {box[0]} {box[1]}" width="100%">{grid}{spokes}'
        f'<polygon points="{poly(1)}" fill="{TEAL}" fill-opacity="0.13" stroke="{TEAL}" stroke-width="1.6"/>'
        f'<polygon points="{poly(2)}" fill="{GOLD}" fill-opacity="0.22" stroke="{GOLD}" stroke-width="1.8"/>'
        f"{labels}</svg>"
    )


def timeline(items):
    """items: [(标题, [要点...]), ...] → 三列时间轴 HTML"""
    cols = ""
    for title, bullets in items:
        lis = "".join(f"<li>{b}</li>" for b in bullets)
        cols += f'<div class="col"><div class="yr">{title}</div><ul>{lis}</ul></div>'
    return f'<div class="tl">{cols}</div>'
