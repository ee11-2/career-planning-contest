#!/usr/bin/env python3
"""一页 HTML → 逐页 PNG → 16:9 PPTX（图片版保真，零跑版）。

为什么走"截图再拼"而不是直接生成 PPTX 形状：
python-pptx 无法还原网页排版，导出来一定跑版；先截图再铺满整页，
字体、间距、圆角百分百还原，代价是文字不可编辑（比赛上传/放映完全够用）。

用法：
    python3 build_deck.py --slides slides.html --out 生涯发展展示.pptx
    python3 build_deck.py --slides slides.html --out x.pptx --notes notes.json --scale 1.5

slides.html 里每一页写成：<section class="slide">...</section>
notes.json 是字符串数组，一条对应一页的演讲备注。
"""
import argparse
import glob
import json
import os
import shutil
import tempfile

from playwright.sync_api import sync_playwright


def render(slides_html, outdir, scale=1.5):
    os.makedirs(outdir, exist_ok=True)
    files = []
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 720}, device_scale_factor=scale)
        pg.goto("file://" + os.path.abspath(slides_html))
        pg.wait_for_timeout(1200)
        els = pg.query_selector_all("section.slide")
        if not els:
            raise SystemExit("没找到 section.slide，检查 slides.html")
        for i, el in enumerate(els, 1):
            f = os.path.join(outdir, f"s{i:02d}.png")
            el.screenshot(path=f)
            files.append(f)
        b.close()
    return files


def build_pptx(files, out_path, notes=None):
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for i, f in enumerate(files):
        s = prs.slides.add_slide(blank)
        s.shapes.add_picture(f, 0, 0, width=prs.slide_width, height=prs.slide_height)
        if notes and i < len(notes):
            s.notes_slide.notes_text_frame.text = notes[i]
    prs.save(out_path)
    return out_path


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--notes", help="JSON 数组，一条一页")
    ap.add_argument("--scale", type=float, default=1.5, help="1.5 → 1920x1080")
    ap.add_argument("--keep", action="store_true", help="保留中间 PNG")
    a = ap.parse_args()

    notes = None
    if a.notes:
        notes = json.load(open(a.notes, encoding="utf-8"))

    work = tempfile.mkdtemp(prefix="deck-")
    files = render(a.slides, work, a.scale)
    build_pptx(files, a.out, notes)
    size = os.path.getsize(a.out) // 1024
    print(f"OK  {a.out}  {len(files)}页  {size}KB")
    if size > 50 * 1024:
        print("!! 超过 50MB 上限，降低 --scale 或把 PNG 转 JPEG")
    if a.keep:
        dst = os.path.splitext(a.out)[0] + "_slides"
        shutil.copytree(work, dst, dirs_exist_ok=True)
        print("PNG 保留在", dst)
    else:
        shutil.rmtree(work, ignore_errors=True)
