#!/usr/bin/env python3
"""常驻浏览器驱动：用文件队列收发命令，进程常驻，浏览器窗口一直开着。

用法：
    python3 driver.py          # 前台/后台启动，会弹出一个持久化 profile 的 Chromium
    python3 send.py '{"action":"goto","url":"..."}'   # 另一个终端发命令

环境变量：
    ZGS_PROFILE  浏览器 profile 目录（默认 ~/.cache/zgs-profile）
    ZGS_RUN      命令/结果文件目录（默认 /tmp/zgs-helper）

命令集：
    goto {url}                 跳转
    js {code}                  执行 JS 并返回结果（最常用）
    mouse {x,y}                真实鼠标点击（能触发 React/SVG 交互）
    type {text}                键盘输入（需先点击聚焦）
    shot {path, full?}         截图
    dump {n?}                  取页面纯文本
    upload {sel, files[]}      给 file input 塞文件
    pages                      列出所有标签页
    quit                       关掉浏览器
"""
import json
import os
import time

from playwright.sync_api import sync_playwright

PROFILE = os.environ.get("ZGS_PROFILE", os.path.expanduser("~/.cache/zgs-profile"))
RUNDIR = os.environ.get("ZGS_RUN", "/tmp/zgs-helper")
CMD = os.path.join(RUNDIR, "cmd.json")
RES = os.path.join(RUNDIR, "res.json")
LOG = os.path.join(RUNDIR, "driver.log")

os.makedirs(RUNDIR, exist_ok=True)
os.makedirs(os.path.dirname(os.path.expanduser(PROFILE)) or ".", exist_ok=True)


def log(msg):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(time.strftime("%H:%M:%S ") + str(msg) + "\n")


def write_res(obj):
    tmp = RES + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, RES)


def main():
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            PROFILE,
            headless=False,
            no_viewport=True,
            args=["--start-maximized", "--disable-blink-features=AutomationControlled"],
        )
        pg = ctx.pages[0] if ctx.pages else ctx.new_page()
        log("launched profile=" + PROFILE)
        idle = 0
        while True:
            if not os.path.exists(CMD):
                time.sleep(1.0)
                idle += 1
                if idle > 14400:
                    log("idle timeout")
                    break
                continue
            idle = 0
            try:
                with open(CMD, encoding="utf-8") as f:
                    cmd = json.load(f)
                os.remove(CMD)
            except Exception:
                time.sleep(0.4)
                continue

            act = cmd.get("action")
            try:
                pg = ctx.pages[-1] if ctx.pages else pg
                if act == "goto":
                    pg.goto(cmd["url"], wait_until=cmd.get("wait", "domcontentloaded"), timeout=60000)
                    write_res({"ok": True, "url": pg.url, "title": pg.title()})
                elif act == "js":
                    write_res({"ok": True, "url": pg.url, "value": pg.evaluate(cmd["code"])})
                elif act == "mouse":
                    pg.mouse.click(int(cmd["x"]), int(cmd["y"]))
                    write_res({"ok": True, "url": pg.url})
                elif act == "type":
                    pg.keyboard.type(cmd["text"])
                    write_res({"ok": True})
                elif act == "shot":
                    pg.screenshot(path=cmd["path"], full_page=cmd.get("full", False))
                    write_res({"ok": True, "url": pg.url})
                elif act == "dump":
                    write_res({"ok": True, "url": pg.url, "text": pg.inner_text("body")[: cmd.get("n", 4000)]})
                elif act == "upload":
                    pg.set_input_files(cmd["sel"], cmd["files"])
                    write_res({"ok": True})
                elif act == "pages":
                    write_res({"ok": True, "value": [{"i": i, "url": x.url} for i, x in enumerate(ctx.pages)]})
                elif act == "quit":
                    write_res({"ok": True})
                    log("quit")
                    break
                else:
                    write_res({"ok": False, "err": "unknown action " + str(act)})
                log("ok " + str(act))
            except Exception as e:
                write_res({"ok": False, "err": type(e).__name__ + ": " + str(e)[:400]})
                log("ERR " + str(act) + " " + str(e)[:160])
        try:
            ctx.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
