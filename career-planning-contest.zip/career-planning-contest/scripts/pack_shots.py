#!/usr/bin/env python3
"""把截图打成班委/辅导员要的压缩包（一个文件夹 + 里面有编号的图）。

用法：
    python3 pack_shots.py --name "26影像1班-张三" --out 张三-职规赛截图.zip \
        "01_报名信息.png" "02_生涯闯关.png"

每个输入可以写成 "源文件|包内名字" 的形式自定义文件名。
"""
import argparse
import os
import zipfile


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True, help="压缩包里的文件夹名，一般写 班级-姓名")
    ap.add_argument("--out", required=True)
    ap.add_argument("files", nargs="+")
    a = ap.parse_args()

    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as z:
        for item in a.files:
            src, _, alias = item.partition("|")
            if not os.path.exists(src):
                raise SystemExit("找不到文件：" + src)
            inner = alias.strip() or os.path.basename(src)
            z.write(src, f"{a.name}/{inner}")

    size = os.path.getsize(a.out) // 1024
    print(f"OK  {a.out}  {size}KB")
    for n in zipfile.ZipFile(a.out).namelist():
        print("   ", n)


if __name__ == "__main__":
    main()
