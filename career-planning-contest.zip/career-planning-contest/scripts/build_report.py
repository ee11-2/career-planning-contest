#!/usr/bin/env python3
"""把一份 HTML 正文片段排版成 A4 PDF（生涯发展报告 / 招聘简章 / 任何 A4 文档）。

关键坑（已踩）：Chromium 的 page.pdf(margin=...) 参数**不生效**，
页边距只能写在 CSS 的 @page 里。所以这里固定用 assets/report.css。

用法：
    python3 build_report.py --body body.html --out 报告.pdf
    python3 build_report.py --body body.html --out 报告.pdf --bar "三甲:79,二级:41,基层:12" \
        --radar "影像解剖:85:55,临床沟通:80:75"
    python3 build_report.py --body body.html --check   # 只统计字数，不出 PDF

正文里可用占位符：
    {{BAR}} {{RADAR}} {{TIMELINE}}   会被替换成对应图形
"""
import argparse
import os
import re
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figures  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
CSS = os.path.join(SKILL, "assets", "report.css")


def parse_pairs(spec, arity):
    out = []
    for chunk in [c for c in (spec or "").split(",") if c.strip()]:
        parts = chunk.split(":")
        if arity == 2:
            out.append((parts[0].strip(), float(parts[1])))
        else:
            out.append((parts[0].strip(), float(parts[1]), float(parts[2])))
    return out


def count_cjk(html):
    plain = re.sub(r"<[^>]+>", "", html)
    return len(re.findall(r"[\u4e00-\u9fa5]", plain)), len(re.sub(r"\s", "", plain))


def build(body_path, out_path, bar=None, radar=None, timeline=None):
    body = open(body_path, encoding="utf-8").read()
    if bar:
        body = body.replace("{{BAR}}", figures.bar_svg(parse_pairs(bar, 2)))
    if radar:
        body = body.replace("{{RADAR}}", figures.radar_svg(parse_pairs(radar, 3)))
    if timeline:
        pairs = []
        for chunk in timeline.split(";"):
            if not chunk.strip():
                continue
            title, _, rest = chunk.partition("=")
            pairs.append((title.strip(), [b.strip() for b in rest.split("|") if b.strip()]))
        body = body.replace("{{TIMELINE}}", figures.timeline(pairs))

    css = open(CSS, encoding="utf-8").read()
    html = (
        '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><style>'
        + css
        + "</style></head><body>"
        + body
        + "</body></html>"
    )

    tmp = os.path.join(tempfile.gettempdir(), "report_preview.html")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(html)

    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 680, "height": 962})   # A4 减 30mm 边距的真实内容宽
        pg.goto("file://" + tmp)
        pg.wait_for_timeout(800)
        # 打印前先量一下有没有横向溢出（宽度换算见 report.css 的 @page margin）
        sw = pg.evaluate("document.documentElement.scrollWidth")
        pg.pdf(path=out_path, format="A4", print_background=True)
        b.close()

    cjk, chars = count_cjk(body)
    size = os.path.getsize(out_path) // 1024
    try:
        import pypdf

        pages = len(pypdf.PdfReader(out_path).pages)
    except Exception:
        pages = "?"
    print(f"OK  {out_path}  {size}KB  {pages}页  汉字{cjk}  全字符{chars}  scrollWidth={sw}")
    if cjk > 2000:
        print("!! 警告：汉字数超过 2000，成长赛道报告有字数上限")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--body")
    ap.add_argument("--out")
    ap.add_argument("--bar", help='例："三甲医院:79,二级医院:41,基层机构:12"')
    ap.add_argument("--radar", help='例："影像解剖:85:55,临床沟通:80:75"（轴名可用 | 换行）')
    ap.add_argument("--timeline", help='例："大一 · 打地基=要点1|要点2;大二 · 进现场=要点3"')
    ap.add_argument("--check", action="store_true", help="只统计字数")
    a = ap.parse_args()

    if not a.body:
        ap.error("--body 必填（例：--body body.html）")

    if a.check or not a.out:
        html = open(a.body, encoding="utf-8").read()
        cjk, chars = count_cjk(html)
        print(f"汉字 {cjk} / 全字符 {chars}")
        sys.exit(0 if cjk <= 2000 else 1)

    build(a.body, a.out, a.bar, a.radar, a.timeline)
