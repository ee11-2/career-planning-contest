# 踩坑清单（都是实测踩出来的，别重踩）

## 一、PDF 导出（Chromium / Playwright）

**1. `page.pdf(margin=...)` 参数不生效。**
实测四组对照（A: @page margin 0 + 无 margin 参数；B: @page 0 + margin 15mm；
C: @page 20mm + 无参数；D: @page 20mm + margin 15mm），结果只跟 CSS 有关：
只有 `@page { margin: 20mm }` 起作用，API 的 margin 全被忽略。
→ 页边距必须写进 CSS，`build_report.py` 已把这条固化进 `assets/report.css`。

**2. PDF 背景透明，在深色阅读器里整页发黑。**
`html, body { background:#fff }` 必须显式写。打印时 `print_background=True` 只管
"要不要打印背景色"，不管"背景是不是白的"。

**3. 屏幕截图 ≠ 打印版面。**
用 `emulate_media('print')` 在 680px 宽（A4 减 30mm 边距）下截图才是真实排版。
在 794px（A4 满宽）下看会觉得文字贴边，那是假象。

**4. 验 PDF 别只信文本提取。**
`pypdf` 抽文字能过，但可能整页错位。用
`sips -s format png --resampleWidth 1100 x.pdf --out p.png` 逐页转图看；
单页验证可以先用 `pypdf.PdfWriter` 拆成单页 PDF 再转。

**5. 分页平衡。**
内容高度除以页高 ≈ 2.35 时，末页只有 1/4 内容，很难看。
两条路：压字号塞进 2 页（撑不住就放弃），或补一张图/表把末页填到 70%+。
`h2, h3 { page-break-after: avoid }` 防标题掉页底。

## 二、React 表单自动化

**6. 直接改 `.value` 无效。**
React 受控组件只认它自己的 onChange。必须用原生 setter：

```js
const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
set.call(el, '文字');
el.dispatchEvent(new Event('input',  {bubbles:true}));
el.dispatchEvent(new Event('change', {bubbles:true}));
```

**7. 合成 `click()` 对图形化卡片不灵。**
`element.dispatchEvent(new MouseEvent('click'))` 对普通按钮够用，
对 SVG / 图片卡片 / 带 pointer 效果的组件经常没反应。**改用真实鼠标**：
`page.mouse.click(x, y)`，并且先 `scrollIntoView({block:'center'})` 再取 rect。

**8. 坐标不能硬编码。**
同一个页面，内容长短不同会把卡片从 y=709 推到 y=773；填完表单后按钮也会位移。
标准姿势：`scrollIntoView` → `getBoundingClientRect()` → 立刻 `mouse.click`，
三步放在同一轮里，中间不要插 `sleep` 以外的异步操作。

**9. 元素在视口外时 rect 可能是 (0,0)。**
拿不到坐标就再滚一次，或改点外层容器（叶子节点常是 0×0）。

**10. 提交后不一定跳转。**
判断成功要看 `location.href` 变化或出现成功提示，不能只看"页面还在"。
反过来，卡住时也别反复点——先抓 `[class*=explain]` 的错误文案。

## 三、这个平台专属的坑

**11. 「编辑报名信息」页会清空目标职业的自定义名。**
保存时只报"请输入"、不报哪个字段，点了十几下都没反应。
→ 进编辑页先执行：
`document.querySelector('input[placeholder="请输入你的目标职业名称"]').value`
为空就补填再保存。

**12. 目标职业限 10 字。**
"医学影像AI应用工程师"是 11 字，会被截。命名先数字数。

**13. 指导教师三项必填。**
姓名、手机号、所在院校缺一不可；院校要先输关键词（如"山东医学"）再从下拉里点选，
直接填字符串不算选中。

**14. 闯关的笃行/领悟要按顺序。**
领悟只有文本域时看着能独立提交，实际会静默失败；先做笃行。
第 6 关起会弹「请先完成如下关卡任务」。

**15. 学信网掉登录。**
重启浏览器进程 = 掉登录（会话级 cookie）。
所以 driver 要常驻，别每次操作都重开；万一重开，让用户重新扫码。

## 四、内容层面

**16. 字数按汉字算，不按字符算。**
"文字不超过 2000 字"通常指汉字数；含标点、数字的"字符数"会多出 30% 左右。
`build_report.py --check` 给的第一个数是汉字，第二个是去空白全字符，卡第一个。

**17. 数据要能溯源。**
报告里的行业数据要么标注来源和口径，要么改成定性表述。
编造数字在答辩时一问就穿。

**18. 不要替人编经历。**
获奖、访谈对象姓名、实习单位这类一旦被核查就是材料不实。
AI 只做"组织和排版"，事实必须由本人提供——这条对代做业务尤其重要（见 SKILL.md）。
